import Cocoa

let Celciustemperature=39.0
let Farenheittemperature=(((Celciustemperature)*9/5))+32
print ("\(Celciustemperature)°C is \(Farenheittemperature)°F")
