import Cocoa

let sweets: [String] = ["Cake","halwa","gulab jamun"]
let uniquesweets = Set(["Cake","halwa","gulab jamun","gulab jamun","Cake","halwa"])
print("Number of items in this array= \(sweets.count)")
print("Number of unique items in the array= \(uniquesweets.count)")
