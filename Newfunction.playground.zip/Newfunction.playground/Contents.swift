import Cocoa

func pythagoras(a: Double, b: Double) -> Double{
    return sqrt(a*a + b*b)
    }
print(pythagoras(a: 3, b: 4))

