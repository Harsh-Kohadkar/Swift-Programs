import Cocoa
var x = Int ()
var z = Int ()
var k = Int ()

enum SquareRootError: Error {
    case OutOfRange
    case NoRootPossible
}

func squareRoot (of x: Int) throws-> String {
    for z in 1...100 {
    if x == z * z {
        return "root = \(z)"
    }
        
         if (x>10000 && x<1) {throw SquareRootError.OutOfRange}
        else {throw SquareRootError.NoRootPossible}
        }
    return "Help"}
do { try squareRoot(of: 100); print("The root is \(z)")}
catch SquareRootError.OutOfRange {
    print("Out of bounds")
} catch SquareRootError.NoRootPossible {
    print("No Root")
} catch {
    print("Help")
}
